/* Generated automatically. */
static const char configuration_arguments[] = "/opt/Espressif/crosstool-NG/.build/src/gcc-5.1.0/configure --build=x86_64-build_unknown-linux-gnu --host=x86_64-build_unknown-linux-gnu --target=xtensa-esp108-elf --prefix=/opt/Espressif/crosstool-NG/builds/xtensa-esp108-elf --with-local-prefix=/opt/Espressif/crosstool-NG/builds/xtensa-esp108-elf/xtensa-esp108-elf/sysroot --disable-libmudflap --with-sysroot=/opt/Espressif/crosstool-NG/builds/xtensa-esp108-elf/xtensa-esp108-elf/sysroot --with-newlib --enable-threads=no --disable-shared --with-pkgversion='crosstool-NG 1.21.0' --disable-__cxa_atexit --with-gmp=/opt/Espressif/crosstool-NG/.build/xtensa-esp108-elf/buildtools --with-mpfr=/opt/Espressif/crosstool-NG/.build/xtensa-esp108-elf/buildtools --with-mpc=/opt/Espressif/crosstool-NG/.build/xtensa-esp108-elf/buildtools --with-isl=/opt/Espressif/crosstool-NG/.build/xtensa-esp108-elf/buildtools --with-cloog=/opt/Espressif/crosstool-NG/.build/xtensa-esp108-elf/buildtools --with-libelf=/opt/Espressif/crosstool-NG/.build/xtensa-esp108-elf/buildtools --enable-lto --enable-target-optspace --without-long-double-128 --disable-libgomp --disable-libmudflap --disable-nls --disable-multilib --enable-languages=c,c++";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
